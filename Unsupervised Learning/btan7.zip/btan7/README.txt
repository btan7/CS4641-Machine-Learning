All algorithms were run on Weka with the default seed settings.

ICA was run using the icaAnalysis.py script in the ICA folder using the command python icaAnalysis.py FILENAME
	WHERE: FILENAME is the name of the .arff file of the ICA filtered dataset
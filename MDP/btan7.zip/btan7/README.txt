Run rl_sim from the command line:

java -jar rl_sim.jar

OR

double click the .jar file provided to start the UI.

Value/Policy Iteration
1. Choose method (either Value Iteration or Policy Iteration)
2. LoadMaze
3. Upload one of the mazes from the Mazes folder
4. Adjust PJOG
5. Initialize
6. Update
7. Execute

For Q-Learning:
1. Choose Q-Learning
2. LoadMaze
3. Upload one of the mazes from the Mazes folder
4. Adjust PJOG
5. Initialize
6. Update
7. Enter number of cycles
8. Cycle